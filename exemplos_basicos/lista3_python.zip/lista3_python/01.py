print(" ")
print("Lista de Grandes Times de SP e Rj: ")
print(" ")

times = ["Corinthians", "São Paulo",
         "Palmeiras", "Santos"]

for time in times:
    print(time)
    print(" ")