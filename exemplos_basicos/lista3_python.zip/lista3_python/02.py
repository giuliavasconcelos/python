print(" ")
print("Lista de Estados do Sudoeste: ")
print(" ")

estados = ["Santo André", "São Bernardo", "SCS", "Mauá"]

for i, estado in enumerate(estados, 1):
    print(f"{i} - {estado}")
    print(" ")